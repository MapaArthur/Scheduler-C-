﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ListLibrary;

namespace TI_AED_LABAED_SO_Forms
{
    class ListaPrioridade : List
    {
        public ListaPrioridade() : base() { }
    }
}
