﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;
using MetroFramework.Controls;
using CircularProgressBar;

namespace TI_AED_LABAED_SO_Forms
{
    public partial class FormInformation : MetroForm
    {
        public FormInformation()
        {
            InitializeComponent();
        }
    }
}
